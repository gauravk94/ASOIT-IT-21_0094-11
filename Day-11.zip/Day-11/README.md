# Image-Hosting

This Repository contains project images for learners to work with.
Belongs to [Joy Shaheb YouTube Channel](https://www.youtube.com/c/JoyShaheb)

## To download just 1 single folder,

- go to the desired folder,
- copy the url,
- go to [downgit](https://minhaskamal.github.io/DownGit/#/home) &
- follow the steps on the video 👇 ->

![](https://cloud.githubusercontent.com/assets/5456665/17822364/940bded8-6678-11e6-9603-b84d75bccec1.gif)
